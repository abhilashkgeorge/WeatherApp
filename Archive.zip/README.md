# WeatherApp
Assignment
Accomplished Tasks : 

UI 
Splash Screen
Successsfully made the API call and was able to display the results in the home UI .
implemented MVVM Architecture and is able to display the result from the view model directly to the view.
Search Functionality 
Side Menu Bar


To Do's:

State Name. Since the API Doesnot provide us with the name of the state , I am working on implementing the state name using CoreLocation.

Faced issues while adding Favourites and recents Functionality 

Landscape support, images from server


